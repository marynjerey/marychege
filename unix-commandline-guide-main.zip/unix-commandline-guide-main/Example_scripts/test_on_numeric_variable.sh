echo "My process identifier is $$"
if [ $a -gt 5 ]
then
  echo "a is strictly greater than 5"
else
  echo "a is less than or equal to 5"
fi
