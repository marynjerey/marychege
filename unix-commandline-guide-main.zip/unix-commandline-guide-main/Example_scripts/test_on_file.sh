if [ -e hello.txt ]
then
  echo "The file exists!"
else
  echo "The file doesn't exist!"
fi
