# unix-commandline-guide
A walk through the universe of the Bash shell

Please follow [this link](https://hpc.ilri.cgiar.org/~jbaka/Recordings_Unix_training/) to get the [recordings of the Zoom webinar sessions](https://hpc.ilri.cgiar.org/~jbaka/Recordings_Unix_training/).


For those of you who want to go a bit further, the definitive resource regarding Bash is the excellent [Advanced Bash Scripting Guide (ABS)](https://tldp.org/LDP/abs/html/).
